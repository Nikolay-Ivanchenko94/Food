package com.example.food.yep;

public class Location {
    private String address1;
    private String city;
    private int zip_code;
    private String country;
    private String state;

}
